package com.zej.mycat.servlet;

import com.zej.mycat.MyCatHttpRequest;
import com.zej.mycat.MyCatHttpResponse;
import com.zej.mycat.MyCatServlet;

public class TestServlet extends MyCatServlet {
    @Override
    public void doGet(MyCatHttpRequest request, MyCatHttpResponse response) throws Exception {
        String name = request.getParameter("name");
        String content = "Say hello to " + name;
        response.writeDynamic(content);
    }

    @Override
    public void doPost(MyCatHttpRequest request, MyCatHttpResponse response) throws Exception {
        doGet(request, response);
    }
}
