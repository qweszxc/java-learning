idea项目，打开运行com.zej.mycat.Main
浏览器输入localhost:8888/test.html

MyCat web服务器，支持动态和静态资源访问
静态资源位于statics目录，包括html,css,js
动态资源Servlet在com.zej.mycat.servlet中定义