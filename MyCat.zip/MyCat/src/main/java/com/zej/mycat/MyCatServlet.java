package com.zej.mycat;

public abstract class MyCatServlet {
    public abstract void doGet(MyCatHttpRequest request, MyCatHttpResponse response) throws Exception;
    public abstract void doPost(MyCatHttpRequest request, MyCatHttpResponse response) throws Exception;
}
