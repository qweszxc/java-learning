package com.zej.mycat;

public class Main {
    public static void main(String[] args) {
        MyCatServer myCatServer = new MyCatServer("com.zej.mycat.servlet");
        try {
            myCatServer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
