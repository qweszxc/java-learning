package com.zej.mycat.servlet;

import com.zej.mycat.MyCatHttpRequest;
import com.zej.mycat.MyCatHttpResponse;
import com.zej.mycat.MyCatServlet;

public class DefaultMyCatServlet extends MyCatServlet {
    @Override
    public void doGet(MyCatHttpRequest request, MyCatHttpResponse response) throws Exception {
        String uri = request.getUri();
        if(uri.indexOf("?")!=-1) {
            String name = uri.substring(0, uri.indexOf("?"));
            response.writeDynamic("404 not found: " + name);
        }else{
            response.writeDynamic("404 not found: " + uri);
        }
    }

    @Override
    public void doPost(MyCatHttpRequest request, MyCatHttpResponse response) throws Exception {
        doGet(request, response);
    }
}
