package com.zej.mycat;

import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.QueryStringDecoder;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class MyCatHttpRequest {
    private HttpRequest request;
    public MyCatHttpRequest(HttpRequest request){
        this.request = request;
    }

    public String getUri(){
        return request.uri();
    }

    public String getPath(){
        QueryStringDecoder decoder = new QueryStringDecoder(request.uri());
        return decoder.path();
    }

    public Map<String, List<String>> getParameters() throws IOException {
        return HttpRequestUtils.getParameters(request);
    }

    public List<String> getParameters(String name) throws IOException {
        return getParameters().get(name);
    }

    public String getParameter(String name) throws IOException {
        List<String> parameters = getParameters(name);
        if(parameters==null||parameters.size()==0){
            return null;
        }
        return parameters.get(0);
    }
}
