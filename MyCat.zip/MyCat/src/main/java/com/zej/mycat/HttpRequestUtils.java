package com.zej.mycat;

import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http.multipart.Attribute;
import io.netty.handler.codec.http.multipart.DefaultHttpDataFactory;
import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
import io.netty.handler.codec.http.multipart.InterfaceHttpData;
import io.netty.handler.codec.http.multipart.InterfaceHttpData.HttpDataType;

import java.io.IOException;
import java.util.*;

public class HttpRequestUtils {
    public static Map<String, List<String>> getParameters(HttpRequest request) throws IOException {
        HttpMethod method = request.method();
        if (method == HttpMethod.GET) {
            QueryStringDecoder decoder = new QueryStringDecoder(request.uri());
            return decoder.parameters();
        } else if (method == HttpMethod.POST) {
            Map<String, List<String>> parameters = new HashMap<>();
            HttpPostRequestDecoder decoder = new HttpPostRequestDecoder(new DefaultHttpDataFactory(false), request);
            if (request instanceof HttpContent) {
                decoder.offer((HttpContent) request);
            }
            if (request instanceof LastHttpContent) {
                List<InterfaceHttpData> postData = decoder.getBodyHttpDatas();
                for (InterfaceHttpData data : postData) {
                    if (data.getHttpDataType() == HttpDataType.Attribute) {
                        Attribute attribute = (Attribute) data;
                        String name = attribute.getName();
                        String value = attribute.getValue();
                        // 处理请求参数
                        parameters.put(name, new ArrayList<>());
                        parameters.get(name).add(value);
                        System.out.println(name + ": " + value);
                    }
                }

                decoder.destroy();
                decoder = null;
            }
            return parameters;
        }
        return Collections.emptyMap();
    }
}