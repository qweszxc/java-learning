package com.zej.mycat;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.*;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MyCatHttpResponse {
    private HttpRequest request;
    private ChannelHandlerContext context;
    public MyCatHttpResponse(HttpRequest request, ChannelHandlerContext context){
        this.request = request;
        this.context = context;
    }
    public void writeDynamic(String content){
        // 响应动态资源请求，在servlet中使用
        String responseContent = "{\"message\": \""+ content +"\"}"; // 包装成json
        write(responseContent, "application/json");
    }

    public void writeStatic(String type, String path){
        // 响应静态资源请求
        // 获取statics目录下的文件，写入响应中
        String filePath = "statics" + path;
        String content = "";
        try{
            InputStream in = MyCatHttpResponse.class.getClassLoader().getResourceAsStream(filePath);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder contentBuilder = new StringBuilder();
            String line;
            while((line = reader.readLine()) != null){
                contentBuilder.append(line).append("\n");
            }
            content = contentBuilder.toString();
        }catch (IOException e){
            e.printStackTrace();
        }catch (NullPointerException e){
            write("404 not found", "text/json");
        }
        if(type.equals("html")){
            write(content, "text/html;charset=utf-8");
        }else if(type.equals("css")){
            write(content, "text/css;charset=utf-8");
        }else if(type.equals("js")){
            write(content, "text/javascript;charset=utf-8");
        }
    }

    public void write(String content, String contentType){
        FullHttpResponse response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK,
                Unpooled.wrappedBuffer(content.getBytes(StandardCharsets.UTF_8)));
        HttpHeaders headers = response.headers();
        headers.set(HttpHeaderNames.CONTENT_TYPE, contentType);
        headers.set(HttpHeaderNames.CONTENT_LENGTH, response.content().readableBytes());
        headers.set(HttpHeaderNames.EXPIRES, 0);
        if(HttpUtil.isKeepAlive(request)){
            headers.set(HttpHeaderNames.CONNECTION, HttpHeaderValues.KEEP_ALIVE);
        }
        context.writeAndFlush(response);
    }
}
