package com.zej.mycat;

import com.zej.mycat.servlet.DefaultMyCatServlet;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.codec.http.*;

import java.nio.charset.StandardCharsets;
import java.util.Map;

public class MyCatHandler extends ChannelInboundHandlerAdapter {
    private Map<String, MyCatServlet> nameToServlet;
    private Map<String, String> nameToClassName;

    public MyCatHandler(Map<String, MyCatServlet> nameToServlet, Map<String, String> nameToClassName) {
        this.nameToServlet = nameToServlet;
        this.nameToClassName = nameToClassName;
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        FullHttpRequest httpRequest = null;
        if(msg instanceof FullHttpRequest) {
            httpRequest = (FullHttpRequest) msg;
        }else{
            return;
        }
        String uri = httpRequest.uri();
        System.out.println(uri);
        int parameterIndex = uri.indexOf("?");
        String resourceName = "";
        if(parameterIndex==-1){
            //无参数
            String[] segments = uri.split("/");
            resourceName = segments[segments.length - 1];
        }else{
            resourceName = uri.substring(uri.lastIndexOf("/") + 1,
                    uri.indexOf("?"));
        }
        MyCatServlet myCatServlet = new DefaultMyCatServlet();
        MyCatHttpResponse myCatHttpResponse = new MyCatHttpResponse(httpRequest, ctx);
        MyCatHttpRequest myCatHttpRequest = new MyCatHttpRequest(httpRequest);
        //通过uri判断是静态资源还是动态资源
        if(uri.endsWith(".html")){
            //静态资源使用MyCatHttpResponse.writeStatics响应
            myCatHttpResponse.writeStatic("html", uri);
        }else if(uri.endsWith(".js")){
            myCatHttpResponse.writeStatic("js", uri);
        }else if(uri.endsWith(".css")){
            myCatHttpResponse.writeStatic("css", uri);
        } else {
            //动态资源使用servlet响应
            if(nameToServlet.containsKey(resourceName)){
                myCatServlet = nameToServlet.get(resourceName);
            }else if(nameToClassName.containsKey(resourceName)){
                if(nameToServlet.get(resourceName)==null){
                    synchronized (this){
                        if(nameToServlet.get(resourceName)==null){
                            String className = nameToClassName.get(resourceName);
                            myCatServlet = (MyCatServlet) Class.forName(className).newInstance();
                            nameToServlet.put(resourceName, myCatServlet);
                        }
                    }
                }
            }
            if(httpRequest.method().name().equalsIgnoreCase("GET")){
                myCatServlet.doGet(myCatHttpRequest, myCatHttpResponse);
            }else if(httpRequest.method().name().equalsIgnoreCase("POST")){
                myCatServlet.doPost(myCatHttpRequest, myCatHttpResponse);
            }

        }
        ctx.close();
    }
}
