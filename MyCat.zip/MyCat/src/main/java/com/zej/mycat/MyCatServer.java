package com.zej.mycat;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoop;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MyCatServer {
    private Map<String, MyCatServlet> nameToServlet = new ConcurrentHashMap<>();
    private Map<String, String> nameToClassName = new HashMap<>();
    private String basePackage;
    public MyCatServer(String basePackage){
        this.basePackage = basePackage;
    }
    private void cacheClassName(String basePackage){
        URL resource = this.getClass().getClassLoader().getResource(basePackage.replaceAll("\\.", "/"));
        if(resource==null){
            return;
        }
        File dir = new File(resource.getFile());
//        System.out.println(dir.getPath());
        for(File file : dir.listFiles()){
            if(file.isDirectory()){
                cacheClassName(basePackage + "." + file.getName());
            }else if(file.getName().endsWith(".class")){
                String simpleClassName = file.getName().replace(".class", "").trim();
                nameToClassName.put(simpleClassName.toLowerCase(), basePackage+"."+simpleClassName);
            }
        }
    }
    public void start() throws Exception {
        cacheClassName(basePackage);
        runServer();
    }
    public void runServer() throws InterruptedException {
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try{
            ServerBootstrap bootstrap = new ServerBootstrap();
            bootstrap.group(bossGroup, workerGroup)
                    .option(ChannelOption.SO_BACKLOG, 1024)
                    .childOption(ChannelOption.SO_KEEPALIVE, true)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ChannelInitializer<SocketChannel>() {

                        @Override
                        protected void initChannel(SocketChannel socketChannel) throws Exception {
                            ChannelPipeline channelPipeline = socketChannel.pipeline();
                            channelPipeline.addLast(new HttpServerCodec());
                            channelPipeline.addLast(new HttpObjectAggregator(1024 * 1024));
                            channelPipeline.addLast(new MyCatHandler(nameToServlet, nameToClassName));
                        }
                    });
            ChannelFuture future = bootstrap.bind(8888).sync();
            System.out.println("MyCat启动成功：端口号为8888");
            future.channel().closeFuture().sync();
        }finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }
}
